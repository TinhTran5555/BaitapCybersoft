// 5 số thực
// Tạo biến cho 5 số thực bằng tên soThu1, soThu2 ,soThu3 ,soThu4 ,SoThu5 đồng thời tạo biến cho tổng của 5 số là sum5 và số trung bình là soTrungBinh
// Tính tổng 5 số sau đó chia cho 5
// Gán biến cho 5 số thực soThu1, soThu2 ,soThu3 ,soThu4  và SoThu5 vừa tạo 
// xuất kết quả của số trung bình

var soThu1 = 5;
var soThu2 = 2;
var soThu3 = 3;
var soThu4 = 1;
var soThu5 = 4;
var sum5 = soThu1 + soThu2 + soThu3 + soThu4 + soThu5;
var soTrungBinh = sum5 / 5;

console.log (soTrungBinh)

    
