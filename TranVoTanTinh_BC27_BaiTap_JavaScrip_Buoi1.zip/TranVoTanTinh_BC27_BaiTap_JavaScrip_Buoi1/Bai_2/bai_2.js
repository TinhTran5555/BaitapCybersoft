// 5 số thực
// Tạo biến cho 5 số thực bằng kí tự a, b ,c ,d ,e đồng thời tạo biến cho tổng của 5 số là sum5 và số trung bình là soTrungBinh
// Tính tổng 5 số sau đó chia cho 5
// Gán biến cho 5 số thực a, b ,c ,d  và e vừa tạo
// xuất kết quả của số trung bình

var a = 5;
var b = 2;
var c = 3;
var d = 1;
var e = 4;
var sum5 = a + b + c + d + e;
var soTrungBinh = sum5 / 5;

console.log (soTrungBinh)

    
