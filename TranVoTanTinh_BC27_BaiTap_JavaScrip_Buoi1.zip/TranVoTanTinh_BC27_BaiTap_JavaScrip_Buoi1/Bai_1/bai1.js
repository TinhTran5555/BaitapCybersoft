// Lương 1 ngày, Ngày làm
// Tạo biến cho Lương 1 ngày, số Ngày làm và Lương nhận được
// Gán biến cho Lương 1 ngày và số Ngày làm. Lương nhận được = Lương 1 ngày * Ngày làm
// xuất kết quả Lương nhận được
const luong1Ngay = 100000;
var ngayLam = 5;
var luongNhanDuoc = luong1Ngay * ngayLam;
console.log(luongNhanDuoc)

