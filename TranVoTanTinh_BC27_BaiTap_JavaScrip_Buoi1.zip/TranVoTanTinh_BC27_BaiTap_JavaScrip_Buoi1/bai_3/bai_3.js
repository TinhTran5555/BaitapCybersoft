// Giá USD hiện tại, số tiền muốn quy đồi
// Tạo hằng số giaUSD, soTienMuonQuyDoi, tienVND
// Gán biến cho giaUSD, soTienMuonQuyDoi, tienVND
// tienVND = giaUSD * soTienMuonQuyDoi
// in kết quả bằng console.log
const giaUSD = 23500 ;
var soTienMuonQuyDoi = 2;
var tienVND = giaUSD * soTienMuonQuyDoi + 'VND'
console.log (tienVND)