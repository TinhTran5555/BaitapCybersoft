// Chiều dài hình chữ nhật, chiều rộng hình chữ nhật
// Tạo biến chieuDai , chieuRong, dienTich, chuVi : lưu ý chiều dài phải lớn hơn chiều rộng
// Gán biến cho chieuDai , chieuRong
// Dùng công thức dienTich = chieuDai * chieuRong để tính diện tích
// Dùng công thức chuVi = (chieuDai + chieuRong)/2 để tính chu vi
// Xuất kết quả Chu vi và Diện Tích với console.log
var chieuDai = 4 ;
var chieuRong = 2 ;
var dienTich = chieuDai * chieuRong;
var chuVi = ( chieuDai + chieuRong ) /2;
console.log('Diện tích là : ' + dienTich)
console.log('Chu vi là : ' + chuVi)