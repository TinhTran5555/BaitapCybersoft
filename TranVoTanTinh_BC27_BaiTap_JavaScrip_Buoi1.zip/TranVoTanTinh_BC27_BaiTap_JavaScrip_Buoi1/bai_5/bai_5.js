// Nhập số có 2 chữ số bất kỳ
// Tạo biến soCo2ChuSo, soHangDv , soHangChuc, tong2So
// gán số cho biến soCo2ChuSo
// Dùng công thức soHangDv = soCo2ChuSo % 10 , soHangChuc =  parseInt (soCo2ChuSo/10);
// TÍnh tổng 2 số soHangDv và soHangChuc
// xuất ra kết quả tổng 2 số với console.log
var soCo2ChuSo = 23
var soHangDv = 23 % 10;
var soHangChuc = parseInt (soCo2ChuSo/10);
var tong2So = soHangDv + soHangChuc;
console.log(tong2So)